"""
Number controller.
Middlewares for Number
"""

from src.models import number as models
from template.src.exceptions.custom import NumberException


class NumberController:
    """Methods that implement the middleware for the Number models"""
