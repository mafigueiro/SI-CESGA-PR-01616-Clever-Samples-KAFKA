"""
__init__.py

Project: SI-CESGA-PR-01616-Clever-Samples-KAFKA

Maintainer Marco Alvarezx (mafigueiro@gradiant.org)

Copyright (c) 2025 Centro Tecnolóxico de Telecomunicacións de Galicia (GRADIANT)
All Rights Reserved
"""
